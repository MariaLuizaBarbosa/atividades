<?php

namespace App\Http\Controllers;

use App\Models\ItemVenda;
use App\Models\Venda;
use Illuminate\Http\Request;

class VendaController extends Controller
{
    


    public function store(Request $request)
    {

        $venda = Venda::create([
            'cliente_id' => $request->cliente_id,
            'data_venda' => date('Y-m-d H:i:s'),
            'desconto' => $request->desconto,
        ]);

        //percorrer o array de itens
        //gravar o item da venda dentro do foreach
        // dica: 
        //        precisa da model itens vendas para gravar o item da venda
        //        'venda_id' => $venda->id (serve para pegar o id da venda)
        //        atuailzar o valor da venda de acordo com o calculo do desconto
        // calculo do subtotal

        $subtotalVenda = 0;
        foreach ($request->itens as $item) {
            $subtotalItem = 0;
            $subtotalVenda += $item["quantidade"] * $item["preco_unitario"];
            $subtotalItem = $subtotalItem + ($item['quantidade'] * $item['preco_unitario']);

            ItemVenda::create([
                'cliente_id' =>$venda->id,
                'data_venda',
                'subtotal',
                'desconto',
                'total'
            ]);
        }

        return response()->json([
            'status' => true,
            'message' => "venda com sucesso",
            'data' => $venda
        ]);
    }
}
