<?php

namespace App\Http\Controllers;

use App\Http\Requests\ClienteFormRequest;
use App\Models\Cliente;
use Illuminate\Http\Request;

class ClienteController extends Controller
{
    //

    public function store(ClienteFormRequest $request)
    {
        $cliente = Cliente::create([
            'nome' => $request->nome,
            'email' => $request->email,
            'telefone' => $request->telefone,
            'endereco' => $request->endereco
        ]);

        return response()->json([
            'status' => true,
            'message' => "cadastrado com sucesso",
            'data' => $cliente
        ]);
    }


    public function index()
    {
        $cliente = Cliente::all();

        return response()->json([
            'status' => true,
            'data' => $cliente
        ]);
    }


    public function show($id)
    {
        $cliente = Cliente::find($id);

        if ($cliente == null) {
            return response()->json([
                'status' => false,
                'data' => $cliente
            ]);
        }

        return response()->json([
            'status' => true,
            'message' => 'Cliente encontrado',
            'data' => $cliente
        ]);
    }


    public function update(ClienteFormRequest $request)
    {
        $cliente = cliente::find($request->id);

        if ($cliente == null) {
            return response()->json([
                'status' => false,
                'message' => ''
            ]);

            if (isset($request->nome)) {
                $cliente->nome = $request->nome;
            }
            if (isset($request->email)) {
                $cliente->email = $request->email;
            }
            if (isset($request->telefone)) {
                $cliente->telefone = $request->telefone;
            }
            if (isset($request->endereco)) {
                $cliente->endereco = $request->endereco;
            }
        }

        $cliente->update();

        return response()->json([
            'status' => true,
            'message' => 'Cliente atualizado',
            'data' => $cliente
        ]);
    }


    public function delete($id)
    {
        $cliente = Cliente::find($id);

        if ($cliente == null) {
            return response()->json([
                'status' => false,
                'data' => $cliente
            ]);
        }

        return response()->json([
            'status' => true,
            'message' => 'Cliente excluído',
            'data' => $cliente
        ]);
    }
}
