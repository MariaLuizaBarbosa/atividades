<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProdutoFormRequest;
use App\Models\Produto;
use Illuminate\Http\Request;

class ProdutoController extends Controller
{
    //

    public function store(ProdutoFormRequest $request)
    {
        $produto = Produto::create([
            'nome' => $request->nome,
            'codigo' => $request->codigo,
            'preco' => $request->preco,
            'quantidade_estoque' => $request->quantidade_estoque
        ]);

        return response()->json([
            'status' => true,
            'message' => "cadastrado com sucesso",
            'data' => $produto
        ]);
    }


    public function index()
    {
        $produto = Produto::all();

        return response()->json([
            'status' => true,
            'data' => $produto
        ]);
    }


    public function show($id)
    {
        $produto = Produto::find($id);

        if ($produto == null) {
            return response()->json([
                'status' => false,
                'data' => $produto
            ]);
        }

        return response()->json([
            'status' => true,
            'message' => 'Produto encontrado',
            'data' => $produto
        ]);
    }


    public function update(ProdutoFormRequest $request)
    {
        $produto = Produto::find($request->id);

        if ($produto == null) {
            return response()->json([
                'status' => false,
                'message' => ''
            ]);

            if (isset($request->nome)) {
                $produto->nome = $request->nome;
            }
            if (isset($request->email)) {
                $produto->email = $request->email;
            }
            if (isset($request->telefone)) {
                $produto->telefone = $request->telefone;
            }
            if (isset($request->endereco)) {
                $produto->endereco = $request->endereco;
            }
        }

        $produto->update();

        return response()->json([
            'status' => true,
            'message' => 'Produto atualizado',
            'data' => $produto
        ]);
    }


    public function delete($id)
    {
        $produto = Produto::find($id);

        if ($produto == null) {
            return response()->json([
                'status' => false,
                'data' => $produto
            ]);
        }

        return response()->json([
            'status' => true,
            'message' => 'Produto excluído',
            'data' => $produto
        ]);
    }
}
