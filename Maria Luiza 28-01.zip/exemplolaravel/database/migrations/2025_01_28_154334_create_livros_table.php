<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('livros', function (Blueprint $table) {
            $table->id();
            $table->string ('titulo')->nullable(false);
            $table->string ('autor')->nullable(false);
            $table->string ('ano_publicacao')->nullable(false);
            $table->string ('genero')->nullable(true);
            $table->text ('descricao')->nullable(true);
            $table->string ('editora')->nullable(false);
            $table->string ('isbn')->nullable(false)->unique();
            $table->string ('selo_editorial')->nullable(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('livros');
    }
};
