<?php

namespace App\Http\Controllers;

use App\Models\Livro;
use Illuminate\Http\Request;

class LivroController extends Controller
{
    public function store(Request $request)
    {
        $livro = Livro::create([
            'titulo' => $request->titulo,
            'autor' => $request->autor,
            'ano_publicacao' => $request->ano_publicacao,
            'genero' => $request->genero,
            'descricao' => $request->descricao,
            'editora' => $request->editora,
            'isbn' => $request->isbn,
            'selo_editorial' => $request->selo_editorial
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Salvo',
            'data' => $livro
        ]);
    }



    public function index()
    {
        $livro = Livro::all();

        return response()->json([
            'status' => true,
            'data' => $livro
        ]);
    }



    public function search(Request $request)
    {
        if ($request->tipo_pesquisa == 'titulo') {
            $livro = Livro::where('titulo', 'like', '%' . $request->pesquisa . '%')->get();
        }
        if ($request->tipo_pesquisa == 'autor') {
            $livro = Livro::where('autor', 'like', '%' . $request->pesquisa . '%')->get();
        }
        if ($request->tipo_pesquisa == 'isbn') {
            $livro = Livro::where('isbn', 'like', '%' . $request->pesquisa . '%')->get();
        }

        return response()->json([
            'status' => true,
            'data' => $livro
        ]);
    }



    public function update(Request $request)
    {
        $livro = Livro::find($request->id);

        if ($livro == null) {
            return response()->json([
                'status' => false,
                'message' => 'Não encontrada'
            ]);
        }

        if (isset($request->titulo)) {
            $livro->titulo = $request->titulo;
        }
        if (isset($request->autor)) {
            $livro->autor = $request->autor;
        }
        if (isset($request->ano_publicacao)) {
            $livro->ano_publicacao = $request->ano_publicacao;
        }
        if (isset($request->genero)) {
            $livro->genero = $request->genero;
        }
        if (isset($request->descricao)) {
            $livro->descricao = $request->descricao;
        }
        if (isset($request->editora)) {
            $livro->editora = $request->editora;
        }
        if (isset($request->isbn)) {
            $livro->isbn = $request->isbn;
        }
        if (isset($request->selo_editorial)) {
            $livro->selo_editorial = $request->selo_editorial;
        }

        $livro->update();

        return response()->json([
            'status' => true,
            'message' => 'Atualizado',
            'data' => $livro
        ]);
    }



    public function delete($id)
    {
        $livro = Livro::find($id);
        if ($livro == null) {
            return response()->json([
                'status' => false,
                'message' => 'Não encontrada',
            ]);
        }

        $livro->delete();

        return response()->json([
            'status' => true,
            'message' => 'Excluído'
        ]);
    }



    public function order()
    {
        $livro = Livro::orderBy('titulo')->get();

        return response()->json([
            'status' => true,
            'message' => 'Ordenado',
            'data' => $livro
        ]);
    }
}
