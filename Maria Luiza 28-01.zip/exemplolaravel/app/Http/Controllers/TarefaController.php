<?php

namespace App\Http\Controllers;

use App\Models\Tarfea;
use Illuminate\Http\Request;

class TarefaController extends Controller
{


    public function store(Request $request)
    {
        $tarefa = Tarfea::create([
            'nome' => $request->nome,
            'data_hora' => $request->data_hora,
            'descricao' => $request->descricao
        ]);

        return response()->json([
            'status' => true,
            'message' => 'Salvo',
            'data' => $tarefa
        ]);
    }



    public function index()
    {
        $tarefas = Tarfea::all();

        return response()->json([
            'status' => true,
            'data' => $tarefas
        ]);
    }



    public function show($id)
    {
        $tarefa = Tarfea::find($id);

        if ($tarefa == null) {
            return response()->json([
                'status' => false,
                'message' => 'Tarefa não encontrada'
            ]);
        }

        return response()->json([
            'status' => true,
            'data' => $tarefa
        ]);
    }



    public function update(Request $request)
    {
        $tarefa = Tarfea::find($request->id);

        if ($tarefa == null) {
            return response()->json([
                'status' => false,
                'message' => 'Não encontrada'
            ]);
        }

        if (isset($request->nome)) {
            $tarefa->nome = $request->nome;
        }
        if (isset($request->data_hora)) {
            $tarefa->data_hora = $request->data_hora;
        }
        if (isset($request->decricao)) {
            $tarefa->decricao = $request->decricao;
        }

        $tarefa->update();

        return response()->json([
            'status' => true,
            'message' => 'Atualizado'
        ]);
    }



    public function delete($id)
    {
        $tarefa = Tarfea::find($id);
        if ($tarefa == null) {
            return response()->json([
                'status' => false,
                'message' => 'Não encontrada',
            ]);
        }

        $tarefa->delete();

        return response()->json([
            'status' => true,
            'message' => 'Excluído'
        ]);
    }



    public function search(Request $request)
    {
        $tarefas = Tarfea::where('nome', 'like', '%' . $request->nome . '%')->get();

        return response()->json([
            'status' => true,
            'data' => $tarefas
        ]);
    }


}
